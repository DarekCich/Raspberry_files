let table ;
let configPanel;
let option;
let colors;
let login = "adam22ew3"
let haslo = "abcwqeewq"
//konfiguracja
let back1 = "#000000";
let back2 = "#003e93";
let font1 = "#E05E1F";
let font2 = "#ffffff";
let Responses;
let temp=0;
let numberOfStation="";
let cityName=""
let mode    ="";
let typeOfTransport =""
function config(){
    // Get the root element
    colors      = document.querySelector ( ":root");
    table       = document.getElementById("myTable");
    configPanel = document.getElementById("configPanel");
    option      = document.getElementById("setOption");
    configPanel.style.zIndex    = "-1"
    option.style.zIndex         = "-1"
    colors.style.setProperty('--background', back1);
    colors.style.setProperty('--font',       font1);
    document.getElementById("motyw").innerHTML            = "Retro Style"
    document.getElementById("rodzajTransportu").innerHTML = "Transport Miejski"
    //config przystanku
    cityName        = "gdansk";
    typeOfTransport = "publicTransport"
    numberOfStation = "20"
    //axios
    axios.defaults.baseURL = 'http://localhost:8080'
    //axios.defaults.baseURL = 'http://192.168.0.2:8080'
}
//interfejs użytkownika
function time(){
    let date   =  new Date()
    let hours = String(date.getHours());
    if(hours.length === 1){
        hours = "0" + hours;
    }
    let minutes =  String(date.getMinutes());
    if(minutes.length === 1){
        minutes = "0" + minutes;
    }
    let seconds = String(date.getSeconds());
    if(seconds.length === 1){
        seconds = "0" + seconds;
    }
    document.getElementById('Time').innerHTML=`${hours}:${minutes}:${seconds}`
}
setInterval(time,10)

function left(){
    for (let i = 0; i < table.rows.length; i++) {
        let row = table.rows[i];
        let firstCell = row.cells[0];
        firstCell.classList.add("move-left");
        setTimeout(function() {
            row.removeChild(firstCell);
            row.appendChild(firstCell);
            firstCell.classList.remove("move-left");
        }, 500);
    }
}
function right(){
    for (var i = 0; i < table.rows.length; i++) {
        let row = table.rows[i];
        let lastCell = row.cells[row.cells.length - 1];
        lastCell.classList.add("move-right");
        setTimeout(function() {
            row.removeChild(lastCell);
            row.insertBefore(lastCell, row.cells[0]);
            lastCell.classList.remove("move-right");
        }, 500);
    }
}
function timeClick() {
    configPanel.style.zIndex==="-1" ? configPanel.style.zIndex="5" :  configPanel.style.zIndex="-1";
}
function changeColor(){
    if(colors.style.getPropertyValue('--background')===back1){
        colors.style.setProperty('--background', back2);
        colors.style.setProperty('--font', font2);
        document.getElementById("motyw").innerHTML="New Style"
    }
    else {
        colors.style.setProperty('--background', back1);
        colors.style.setProperty('--font', font1);
        document.getElementById("motyw").innerHTML="Retro Style"
    }
}
//main
async function onstart(){
    config();
    await userSignIn(login, haslo)
    await getZtmInfo(cityName,numberOfStation)
}
//logowanie
async function userSignIn(username, password) {
    await axios.post('api/auth/signin', {
        "username": username,
        "password": password,
    }).then(response => {
        // this.authStatus = true;
        // this.lastHttpCode = response.status;
        // this.userData = response.data;
        // //returning data from LOGIN backend to userData without parsing
        // this.userJwt = response.headers.authorization;
        axios.defaults.headers.common['Authorization'] = response.headers.authorization;
    }).catch(error => {
        if(!(error.code === "ERR_NETWORK")){
            //this.lastHttpCode = error.response.status;
        }else {
            //this.lastHttpCode = 500;
        }console.log(error);
    });
}


//loaders

function loadData(json) {
    if (table.rows.length>0)
        table.deleteRow(0);
    const firstRow = table.insertRow();
    json.map((x)=>{
        const cell = firstRow.insertCell();
        let date = x.estimatedTime;
        let part=[];
        part[0]=""
        part[1]=""
        part[2]=""
        switch (cityName){
            case "warszawa":
                part = date.split(":")
                break;
            case "gdansk":
                part = date.split("T")
                part = part[1].split("Z")
                part = part[0].split(":")
                part[0]  = parseInt(part[0])+2;
                break;
        }
        console.log()
        cell.innerHTML=`<div>${x.tripId}</div> <div>${part[0]}:${part[1]}:${part[2]}</div>`;
    })

}

async function loadStationOptions() {
    if(Responses.length===0){
        document.getElementById("Przystanek").innerHTML = "brak przystankow"
        return;
    }
    if(Responses.length===1){
        await setStationName(0);
        return;
    }
    if(temp===Responses.length){
        temp=0;
    }
    else if(temp<0){
        temp=Responses.length-1;
    }
    if(temp+2>=Responses.length){
        if(temp+1>=Responses.length){
            setOptionValuesStation("secondRow",0);
            setOptionValuesStation("thirdRow" ,1);
        }
        else {
            setOptionValuesStation("secondRow",temp+1);
            setOptionValuesStation("thirdRow" ,0);
        }
    }
    else{
        setOptionValuesStation("secondRow",temp+1);
        setOptionValuesStation("thirdRow" ,temp+2);
    }
    setOptionValuesStation("firstRow" ,temp);
}

function loadCityOptions(){
    if(Responses.length===0){
        document.getElementById("Miasto").innerHTML = "brak Miast"
        return;
    }
    if(Responses.length===1){
        setCityName(0)
        return;
    }
    if(temp===Responses.length){
        temp=0;
    }
    else if(temp<0){
        temp=Responses.length-1;
    }
    if(temp+2>=Responses.length){
        if(temp+1>=Responses.length){
            setOptionValues("secondRow",0);
            setOptionValues("thirdRow" ,1);
        }
        else {
            setOptionValues("secondRow",temp+1);
            setOptionValues("thirdRow" ,0);
        }
    }
    else{
        setOptionValues("secondRow",temp+1);
        setOptionValues("thirdRow" ,temp+2);
    }
    setOptionValues("firstRow" ,temp);
}



// gettery


async function getZtmInfo(url,number){
    document.getElementById("loading").style.zIndex="2"
    await axios.get(`api/ztm/${url}/info/${number}`).then(response => {
        switch (cityName){
            case "warszawa":
                loadData(response.data)
                return;
            case "gdansk":
                loadData(response.data.departures)
                return;
            default:
                return;
        }
    }).catch(() => {
    });
    document.getElementById("loading").style.zIndex="-1"
}
async function getResponse(path){
    await axios.get(path).then(response => {
        Responses = response.data;
    }).catch(error => {
        if(!(error.code === "ERR_NETWORK")){
            //this.lastHttpCode = error.response.status;
        }else {
            //this.lastHttpCode = 500;
        }console.log(error);
    });
    // console.log(responses.data.length)
}


//changers

function changeTypeOfTransport(){
    if (document.getElementById("rodzajTransportu").innerHTML === "Kolej"){
        document.getElementById("rodzajTransportu").innerHTML = "Transport Miejski"
        typeOfTransport="publicTransport"
    }
    else{
        document.getElementById("rodzajTransportu").innerHTML = "Kolej"
        typeOfTransport="trains"
    }
}

async function changeTemp(number){
    temp += number;
    if(mode==='city'){
        await loadCityOptions();
        return;
    }
    if(mode === "station"){
        await loadStationOptions();
        return
    }
    option.style.zIndex="-1";
}



//setters

function setCityName(id){
    document.getElementById("Miasto").innerHTML = Responses[id]
    switch (Responses[id]){
        case "warszawa":
            cityName="warszawa";
            return;
        case "gdańsk":
            cityName="gdansk";
            return;
        default:
            cityName=""
            return;
    }
}
async function setCity(){
    mode = "city"
    await getResponse(`api/displays/all/${typeOfTransport}`);
    await loadCityOptions();
    option.style.zIndex = "6";
}

async function setStation() {
    mode="station"
    await getResponse(`/api/ztm/${cityName}/displays`);
    await loadStationOptions();
    option.style.zIndex = "6";
}

 function setStationName(id){
    document.getElementById("Przystanek").innerHTML = Responses[id].name
    numberOfStation=Responses[id].displayCode;
    getZtmInfo(cityName, numberOfStation).then(() => {});
}

function setOptionValues(id, value){
    document.getElementById(id).innerHTML=Responses[value];
    document.getElementById(id ).setAttribute("value",`${value}`)
}

function setOptionValuesStation(id, value){
    document.getElementById(id).innerHTML=Responses[value].name;
    document.getElementById(id ).setAttribute("value",`${value}`)
}

async function setOption(id){
    if(mode==='city'){
        setCityName(parseInt(document.getElementById(id).getAttribute("value")))
    }
    else if(mode ==="station"){
        await setStationName(document.getElementById(id).getAttribute("value"))
    }
    option.style.zIndex="-1";
}

